# Stack dan konvensi folder

**Produk:** Next Swimming School  
**Status:** Acuan kerja agen  
**Tanggal:** 16 September 2026

Sumber: `docs/01-prd.md` bab 4. Hierarki kebenaran: `docs/README.md`.

---

## 1. Yang terkunci di dokumen

| Lapis | Keputusan |
|---|---|
| UI framework | Next.js App Router, TypeScript |
| Styling | Tailwind CSS v4, token di `src/app/globals.css` (`@theme inline`) |
| Konfigurasi Tailwind | **Tidak ada** `tailwind.config.ts` |
| Font | Plus Jakarta Sans (`font-display`), Inter (`font-sans`), JetBrains Mono (`font-mono`, panel saja) |
| Komponen | `src/components/ui/`: `<Btn>`, `<Status>`, `<Card>`, `Field`, `Modal`, `Icon` |
| Navigasi panel | Tab `useState` di dalam **satu** `page` per peran, bukan rute per menu |
| Bahasa UI | Inggris di kode; ID = widget Google Translate (`docs/06-teknis/I18N.md`) |
| Peta / GPS | Pin `branches` atau pin kelas; geolokasi peramban pelatih; bukan pagar geografis |
| WhatsApp | `wa.me` + nomor Admin pusat; bukan WhatsApp Business API |
| AI in-app | Tidak ada |
| Auth, Postgres, storage | Supabase |
| Query dan migrasi | Drizzle ORM plus `drizzle-kit`. Agen jalankan dari terminal |
| Env | `.env.example` di akar repo |

## 2. Yang belum dikunci (jangan diisi agen)

| Kode PRD | Topik |
|---|---|
| TBD-03 | Sudah dikunci: Supabase plus Drizzle. Jangan ganti vendor. |
| TBD-02 | Anggaran infrastruktur dan tenggat rilis |
| TBD-05 | Ambang latensi API |
| TBD-04 | Dasar hukum retensi / privasi |
| TBD-06 | Gerbang bayar versi mendatang. Ditolak sekarang |

Jangan menukar Drizzle dengan Prisma. Jangan mengarang Firebase atau Auth.js. Rincian koneksi dan perintah migrasi: `CLAUDE.md` bagian 6.

---

## 3. Peta rute

```
Publik
  /                  landing (CMS Owner)
  /register          pendaftaran calon siswa
  /login             (jika ada di kode; jangan gandakan)

Sesi + profiles.role
  /owner             owner, semua branch_id
  /admin             admin | manager_center, satu branch_id
  /coach             coach, class_coaches + coach_branches
  /staff             staff, satu branch_id
  /member            Student (peran member)
  /school            school, schools.profile_id
```

Owner masuk pertama: `POST /api/owner/init-profile`.

Pratinjau Admin dari Owner: `sessionStorage.ownerPreviewBranch`, lalu `/admin`. Bukan cookie. Tidak menaikkan wewenang akun Admin.

Query `?tab=` boleh untuk deep-link, tetapi wewenang tetap di peladen. `/admin?tab=financial` sebagai Admin biasa harus ditolak.

---

## 4. Folder yang diharapkan

Sesuaikan jika kode sudah berbeda; jangan membuat pohon paralel.

```
src/app/
  layout.tsx                 font display + sans; widget terjemahan
  globals.css                @theme inline (ocean, wave, ink, paper, line, semantik)
  page.tsx                   landing
  register/                  US-01
  owner/                     panel Owner (tab)
  admin/                     panel Admin / Manager Center (tab)
  coach/page.tsx
  staff/page.tsx
  member/page.tsx
  school/page.tsx
  api/                       rute di docs/06-teknis/API.md
src/components/ui/           Btn, Status, Card, Field, Modal, Icon, …
src/lib/fonts.ts             JetBrains Mono hanya layout panel
src/i18n/                    jika ada: hanya en sebagai sumber, bukan kamus id
src/lib/db.ts                klien Drizzle (postgres.js, prepare: false)
drizzle/schema.ts            schema Postgres
drizzle.config.ts            drizzle-kit
.env.example                 kunci publik plus DATABASE_URL kosong
```

Alias impor: `@/` → `src/`.

---

## 5. Konvensi kode UI

1. Jangan interpolasi class Tailwind.
2. Jangan `bg-blue-`, `bg-slate-`, `bg-gray-` untuk merek (pengecualian token `archive`).
3. Tombol aksi: `<Btn>`. Status: `<Status kind>`.
4. Formulir: bungkus `<Field label>`.
5. Umpan: `useToast()`, `useConfirm()`.
6. Modal: portal `z-[90]`, overlay `bg-ink/50`.
7. Sentuhan: aksi `md`/`lg` `min-h-[44px]`; input 16 px di lebar ≤640 px.
8. `prefers-reduced-motion` sudah di `globals.css`; jangan `@keyframes` baru tanpa cabang itu.
9. Jangan memuat JetBrains Mono di landing/login.

---

## 6. Isolasi data

KPI-02: peran selain Owner (dan pelatih yang ditautkan ke pusat itu) tidak membaca `branch_id` lain.

Pelatih: daftar siswa kelas lewat API pelatih jika RLS menolak kueri langsung (`/api/coach/class-members`, `/api/coach/attendance-detail`).

Manager Center ≠ Owner meskipun URL `/admin` sama.

---

## 7. Skrip yang diharapkan

Minimal setelah repo hidup: `dev`, `build`, `lint`, plus skrip Drizzle (`db:generate`, `db:migrate` atau setara).

Perubahan tabel: edit schema Drizzle, lalu agen menjalankan `drizzle-kit generate` / `migrate` / `push` di terminal. Bukan SQL Editor dashboard.

Jangan menambah layanan AI, antrian, atau paket i18n routing tanpa addendum PRD.
---
